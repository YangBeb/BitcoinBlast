<?php



$uid = "xxxxxxxxxxx";

$authorization = "xxxxxxxxxxx";

$firebase_instance_id_token = "xxxxxxxxxxx";
